# Copilot Studio Classic Experience

This Edge/Chrome Manifest V3 extension:

- Forces `AgenticAutomationsShellOptIn` to `false`
- Reloads Copilot Studio if the new experience was enabled
- Hides the **New Copilot Studio experience / Try now** promotion
- Hides the **New experience** toggle when it is rendered

## Test locally in Microsoft Edge

1. Extract this ZIP.
2. Open `edge://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `copilot-studio-classic-extension` folder.
6. Open `https://copilotstudio.microsoft.com`.
7. In DevTools Console, verify:

   ```javascript
   localStorage.getItem("AgenticAutomationsShellOptIn")
   ```

   Expected result:

   ```text
   "false"
   ```

## Disable / remove

Go to `edge://extensions` and disable or remove **Copilot Studio Classic Experience**.

## Notes

This relies on the current Copilot Studio client-side preference key
`AgenticAutomationsShellOptIn`. If Microsoft changes the key or the UI structure,
the extension may need to be updated.
(() => {
  "use strict";

  const OPT_IN_KEY = "AgenticAutomationsShellOptIn";
  const CLASSIC_VALUE = "false";
  const PROMO_TEXT = "New Copilot Studio experience";
  const TRY_NOW_TEXT = "Try now";
  const NEW_EXPERIENCE_TEXT = "New experience";

  let reloadTriggered = false;

  function enforceClassicExperience() {
    try {
      const current = localStorage.getItem(OPT_IN_KEY);

      if (current !== CLASSIC_VALUE && !reloadTriggered) {
        localStorage.setItem(OPT_IN_KEY, CLASSIC_VALUE);
        reloadTriggered = true;
        window.location.reload();
        return true;
      }
    } catch (error) {
      console.warn("[Copilot Studio Classic] Could not access localStorage:", error);
    }

    return false;
  }

  function hidePromotionBanner() {
    const buttons = document.querySelectorAll("button");

    for (const button of buttons) {
      const buttonText = (button.textContent || "").trim();

      if (buttonText !== TRY_NOW_TEXT) {
        continue;
      }

      let node = button;

      for (let i = 0; i < 10 && node; i += 1) {
        const text = node.textContent || "";

        if (text.includes(PROMO_TEXT)) {
          node.style.setProperty("display", "none", "important");
          break;
        }

        node = node.parentElement;
      }
    }
  }

  function hideNewExperienceToggle() {
    const candidates = document.querySelectorAll(
      'button, [role="switch"], label, span, div'
    );

    for (const element of candidates) {
      const text = (element.textContent || "").trim();

      if (text !== NEW_EXPERIENCE_TEXT) {
        continue;
      }

      let target =
        element.closest('[role="switch"]') ||
        element.closest("button") ||
        element.parentElement;

      if (!target) {
        continue;
      }

      // Avoid hiding large layout containers accidentally.
      const rect = target.getBoundingClientRect();
      if (rect.width < 400 && rect.height < 120) {
        target.style.setProperty("display", "none", "important");
      }
    }
  }

  function applyUiRestrictions() {
    if (enforceClassicExperience()) {
      return;
    }

    hidePromotionBanner();
    hideNewExperienceToggle();
  }

  // Run immediately.
  applyUiRestrictions();

  // Copilot Studio is a SPA, so watch for React-rendered UI changes.
  const observer = new MutationObserver(() => {
    applyUiRestrictions();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  // Also re-check on navigation/focus in case the preference changes later.
  window.addEventListener("focus", applyUiRestrictions);
  window.addEventListener("pageshow", applyUiRestrictions);

  // Defensive periodic check. Low frequency to avoid unnecessary overhead.
  window.setInterval(applyUiRestrictions, 2000);
})();
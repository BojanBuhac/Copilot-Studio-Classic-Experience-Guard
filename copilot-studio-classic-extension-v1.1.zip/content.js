(() => {
  "use strict";

  const ALLOWED_HOSTS = new Set([
    "copilotstudio.microsoft.com",
    "copilotstudio.preview.microsoft.com"
  ]);

  const OPT_IN_KEY = "AgenticAutomationsShellOptIn";
  const CLASSIC_VALUE = "false";
  const PROMO_TEXT = "New Copilot Studio experience";
  const TRY_NOW_TEXT = "Try now";
  const NEW_EXPERIENCE_TEXT = "New experience";

  let reloadTriggered = false;

  if (!ALLOWED_HOSTS.has(window.location.hostname)) {
    return;
  }

  function enforceClassicExperience() {
    try {
      const current = localStorage.getItem(OPT_IN_KEY);

      if (current !== CLASSIC_VALUE && !reloadTriggered) {
        localStorage.setItem(OPT_IN_KEY, CLASSIC_VALUE);
        reloadTriggered = true;
        window.location.reload();
        return true;
      }
    } catch (error) {
      console.warn("[Copilot Studio Classic Guard] Could not access localStorage:", error);
    }

    return false;
  }

  function hidePromotionBanner() {
    for (const button of document.querySelectorAll("button")) {
      const buttonText = (button.textContent || "").trim();

      if (buttonText !== TRY_NOW_TEXT) {
        continue;
      }

      let node = button;

      for (let i = 0; i < 10 && node; i += 1) {
        const text = node.textContent || "";

        if (text.includes(PROMO_TEXT)) {
          node.style.setProperty("display", "none", "important");
          break;
        }

        node = node.parentElement;
      }
    }
  }

  function hideNewExperienceToggle() {
    const candidates = document.querySelectorAll(
      'button, [role="switch"], label, span, div'
    );

    for (const element of candidates) {
      const text = (element.textContent || "").trim();

      if (text !== NEW_EXPERIENCE_TEXT) {
        continue;
      }

      const target =
        element.closest('[role="switch"]') ||
        element.closest("button") ||
        element.parentElement;

      if (!target) {
        continue;
      }

      const rect = target.getBoundingClientRect();

      if (rect.width < 400 && rect.height < 120) {
        target.style.setProperty("display", "none", "important");
      }
    }
  }

  function applyRestrictions() {
    if (enforceClassicExperience()) {
      return;
    }

    hidePromotionBanner();
    hideNewExperienceToggle();
  }

  applyRestrictions();

  const observer = new MutationObserver(applyRestrictions);

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  window.addEventListener("focus", applyRestrictions);
  window.addEventListener("pageshow", applyRestrictions);

  window.setInterval(applyRestrictions, 2000);
})();
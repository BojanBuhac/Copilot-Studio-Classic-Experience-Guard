# Copilot Studio Classic Experience Guard v1.1

Supported sites:

- https://copilotstudio.microsoft.com/
- https://copilotstudio.preview.microsoft.com/

The extension:

- Forces `AgenticAutomationsShellOptIn` to `false`
- Reloads Copilot Studio if the new experience was enabled
- Hides the **New Copilot Studio experience / Try now** promotion
- Hides the **New experience** toggle when rendered

## Local test in Microsoft Edge

1. Extract the ZIP.
2. Open `edge://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted extension folder.
6. Test both Copilot Studio URLs.
7. In DevTools Console run:

   `localStorage.getItem("AgenticAutomationsShellOptIn")`

Expected result: `"false"`

## Note

The preference is stored per origin. The extension therefore enforces the value independently on both the production and preview Copilot Studio domains.
